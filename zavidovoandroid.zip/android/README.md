# Завидово — Android (Jetpack Compose)

Native Android port of the Zavidovo resort prototype — premium black & gold,
7 screens with live navigation. Rewritten from the React/HTML design into
idiomatic Kotlin + Jetpack Compose.

## Screens

| Screen | What's interactive |
|---|---|
| **Главная** (Home) | greeting, Platinum card, quick actions → booking, **Парковка & валет** «Подать авто» → progress, events strip, recommendations |
| **Услуги** (Services) | category filter chips, catalog → booking |
| **Бронирование** (Booking) | date / time / guest pickers, «Забронировать» → confirmed state |
| **События** (Events) | event list |
| **Консьерж** (Concierge) | quick-reply chips append to chat with a delayed auto-reply, auto-scroll |
| **Карта** (Map) | stylised terrain drawn on Canvas with labelled pins + legend |
| **Профиль** (Profile) | membership card with animated sheen, stats, menu |

## Tech

- Kotlin 2.0.21, Jetpack Compose (BOM 2024.10.01), Material 3
- `minSdk 26`, `targetSdk / compileSdk 35`
- Fonts **Cormorant Garamond** (display) + **Manrope** (UI) bundled as TTFs in
  `app/src/main/res/font/` (Latin + Cyrillic subsets merged), so the Russian UI
  renders offline with no Google Fonts / Play Services dependency.
- Icons reuse the prototype's exact SVG path data, rendered via Compose
  `PathParser` (`ui/components/SvgIcon.kt`) for visual fidelity.

## Project layout

```
app/src/main/java/com/zavidovo/app/
├─ MainActivity.kt            edge-to-edge host
├─ data/Models.kt            domain models + static catalog + Screen enum
└─ ui/
   ├─ ZavidovoApp.kt          scaffold + bottom navigation
   ├─ theme/                  Color, Type (font families), Theme
   ├─ components/             SvgIcon, Icons (paths), ZLogo, SectionLabel, ServiceCard
   └─ screens/                Home, Services, Booking, Events, Concierge, Map, Profile
```

## Build & run

Requires the Android SDK (platform 35) and JDK 17+.

```bash
# point at your SDK (or set ANDROID_HOME)
echo "sdk.dir=/path/to/Android/sdk" > local.properties

./gradlew assembleDebug          # → app/build/outputs/apk/debug/app-debug.apk
./gradlew installDebug           # install on a connected device/emulator
```

Or just open this `android/` folder in Android Studio and press Run.

> Note: this project was scaffolded in a sandbox without network access to
> Google's Maven (AGP) or the Android SDK, so it was not compiled there. Build
> it locally / in Android Studio, which will fetch AGP and the SDK normally.
