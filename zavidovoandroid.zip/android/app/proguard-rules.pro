# Default ProGuard rules for the Zavidovo app.
-keepattributes *Annotation*
