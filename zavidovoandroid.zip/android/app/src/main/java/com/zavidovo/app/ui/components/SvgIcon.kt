package com.zavidovo.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp

/** One SVG <path>: its data plus how to paint it. */
data class IconPath(
    val data: String,
    val stroke: Color? = null,
    val fill: Color? = null,
    val strokeWidth: Float = 1.4f,
    val cap: StrokeCap = StrokeCap.Round,
    val join: StrokeJoin = StrokeJoin.Round,
)

/**
 * Renders SVG path data faithfully by scaling the original viewBox to the
 * requested size — lets us reuse the prototype's exact `d="…"` strings.
 */
@Composable
fun SvgIcon(
    paths: List<IconPath>,
    viewportWidth: Float,
    viewportHeight: Float,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier.size(width, height)) {
        val sx = size.width / viewportWidth
        val sy = size.height / viewportHeight
        withTransform({ scale(sx, sy, pivot = Offset.Zero) }) {
            for (p in paths) {
                val path = PathParser().parsePathString(p.data).toPath()
                p.fill?.let { drawPath(path, color = it) }
                p.stroke?.let {
                    drawPath(path, color = it, style = Stroke(width = p.strokeWidth, cap = p.cap, join = p.join))
                }
            }
        }
    }
}
