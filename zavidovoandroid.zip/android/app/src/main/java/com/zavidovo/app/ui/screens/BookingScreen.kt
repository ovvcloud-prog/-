package com.zavidovo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*

@Composable
fun BookingScreen(serviceId: String, onBack: () -> Unit) {
    val svc = Data.service(serviceId)
    var dateI by rememberSaveable(serviceId) { mutableIntStateOf(0) }
    var time by rememberSaveable(serviceId) { mutableStateOf("18:00") }
    var guests by rememberSaveable(serviceId) { mutableIntStateOf(2) }
    var booked by rememberSaveable(serviceId) { mutableStateOf(false) }

    Column {
        // ── Hero ──
        Box(
            Modifier.fillMaxWidth().height(300.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF221F25), Color(0xFF0B0A0C)))),
        ) {
            Text(svc.hero, color = Gold.copy(alpha = 0.13f), fontFamily = Cormorant,
                fontWeight = FontWeight.SemiBold, fontSize = 38.sp, letterSpacing = 11.sp,
                modifier = Modifier.align(Alignment.Center))
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 18.dp, top = 62.dp)
                    .size(42.dp).clip(CircleShape).background(Color(0x990A0A0B))
                    .border(1.dp, GoldB40, CircleShape).clickable(onClick = onBack),
            ) { SvgIcon(backChevron(Gold), 12f, 20f, 11.dp, 18.dp) }
            Column(
                Modifier.align(Alignment.BottomStart)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF20A0A0B))))
                    .fillMaxWidth().padding(20.dp),
            ) {
                Text(svc.label.uppercase(), color = Gold, fontFamily = Manrope,
                    fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 2.5.sp)
                Spacer(Modifier.height(9.dp))
                Text(svc.name, color = Text, fontFamily = Cormorant, fontWeight = FontWeight.Light, fontSize = 27.sp)
            }
        }

        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 28.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("★★★★★", color = GoldLight, fontSize = 13.sp, letterSpacing = 2.sp)
                Spacer(Modifier.width(8.dp))
                Text("4.9 · 328 отзывов", color = Dim50, fontFamily = Manrope,
                    fontWeight = FontWeight.Medium, fontSize = 12.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text(svc.long, color = Dim60, fontFamily = Manrope, fontSize = 14.sp, lineHeight = 22.sp)
            Spacer(Modifier.height(26.dp))

            // ── Date ──
            SectionLabel("Дата")
            Spacer(Modifier.height(13.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(Data.bookingDates.size) { i ->
                    val (d, n) = Data.bookingDates[i]
                    val active = dateI == i
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(58.dp).clip(RoundedCornerShape(14.dp))
                            .then(if (active) Modifier.background(GoldChipBrush) else Modifier.background(Card))
                            .then(if (active) Modifier else Modifier.border(1.dp, GoldB18, RoundedCornerShape(14.dp)))
                            .clickable { dateI = i }.padding(vertical = 12.dp),
                    ) {
                        Text(d, color = if (active) Color(0x990A0A0B) else Dim40, fontFamily = Manrope,
                            fontWeight = FontWeight.Medium, fontSize = 9.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(7.dp))
                        Text(n, color = if (active) Bg else Text, fontFamily = Cormorant,
                            fontWeight = FontWeight.Medium, fontSize = 19.sp)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))

            // ── Time ──
            SectionLabel("Время")
            Spacer(Modifier.height(13.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Data.bookingTimes.forEach { t ->
                    val active = time == t
                    Box(
                        Modifier.clip(RoundedCornerShape(30.dp))
                            .then(if (active) Modifier.background(GoldChipBrush) else Modifier.background(Card))
                            .then(if (active) Modifier else Modifier.border(1.dp, GoldB20, RoundedCornerShape(30.dp)))
                            .clickable { time = t }.padding(horizontal = 20.dp, vertical = 11.dp),
                    ) {
                        Text(t, color = if (active) Bg else Text, fontFamily = Manrope,
                            fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))

            // ── Guests ──
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
                    .border(1.dp, GoldB16, RoundedCornerShape(16.dp))
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("Гости", color = Text, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("количество персон", color = Dim40, fontFamily = Manrope, fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Stepper("−") { if (guests > 1) guests-- }
                    Spacer(Modifier.width(18.dp))
                    Text("$guests", color = Text, fontFamily = Cormorant, fontWeight = FontWeight.Medium,
                        fontSize = 18.sp, modifier = Modifier.widthIn(min = 18.dp))
                    Spacer(Modifier.width(18.dp))
                    Stepper("+") { if (guests < 8) guests++ }
                }
            }
            Spacer(Modifier.height(28.dp))

            // ── Total ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom) {
                Text("Итого", color = Dim50, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("от ", color = Dim40, fontFamily = Manrope, fontSize = 12.sp)
                    Text("${svc.price} ₽", color = GoldLight, fontFamily = Cormorant,
                        fontWeight = FontWeight.Medium, fontSize = 26.sp)
                }
            }
            Spacer(Modifier.height(20.dp))

            // ── CTA ──
            if (!booked) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(GoldButtonBrush).clickable { booked = true }.padding(18.dp),
                ) {
                    Text("ЗАБРОНИРОВАТЬ", color = Bg, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp, letterSpacing = 2.sp)
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Gold.copy(alpha = 0.08f)).border(1.dp, GoldB50, RoundedCornerShape(16.dp))
                        .padding(18.dp),
                ) {
                    Text("✓ БРОНИРОВАНИЕ ПОДТВЕРЖДЕНО", color = GoldLight, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Детали отправлены консьержу", color = Dim50, fontFamily = Manrope, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun Stepper(symbol: String, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(34.dp).clip(CircleShape)
            .border(1.dp, GoldB40, CircleShape).clickable(onClick = onClick),
    ) {
        Text(symbol, color = Gold, fontFamily = Manrope, fontSize = 20.sp)
    }
}
