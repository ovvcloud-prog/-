package com.zavidovo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.zavidovo.app.ui.ZavidovoApp
import com.zavidovo.app.ui.theme.ZavidovoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            ZavidovoTheme {
                ZavidovoApp()
            }
        }
    }
}
