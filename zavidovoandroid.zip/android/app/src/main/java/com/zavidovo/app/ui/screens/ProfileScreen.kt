package com.zavidovo.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*

@Composable
fun ProfileScreen() {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 28.dp)) {
        Text("ЧЛЕНСТВО", color = Gold, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(11.dp))
        Text("Личный кабинет", color = Text, fontFamily = Cormorant, fontWeight = FontWeight.Light, fontSize = 34.sp)
        Spacer(Modifier.height(24.dp))

        // ── Membership card with animated sheen ──
        val transition = rememberInfiniteTransition(label = "sheen")
        val shimmer by transition.animateFloat(
            initialValue = -1f, targetValue = 2f,
            animationSpec = infiniteRepeatable(
                animation = tween(6000, easing = EaseInOut),
                repeatMode = RepeatMode.Restart),
            label = "shimmerX",
        )
        Box(
            Modifier.fillMaxWidth().height(222.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(
                    listOf(Color(0xFF26221F), Color(0xFF0C0B0D), Color(0xFF1A1620))))
                .border(1.dp, GoldB40, RoundedCornerShape(22.dp)),
        ) {
            // sheen sweep
            Box(
                Modifier.matchParentSize().background(
                    Brush.linearGradient(
                        colors = listOf(Color.Transparent, GoldLight.copy(alpha = 0.12f), Color.Transparent),
                        start = Offset(shimmer * 800f, 0f),
                        end = Offset(shimmer * 800f + 400f, 200f),
                    )))
            Column(Modifier.fillMaxSize().padding(24.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ZLogo(size = 26.dp, color = GoldLight)
                        Spacer(Modifier.width(11.dp))
                        Text("ЗАВИДОВО", color = GoldLight, fontFamily = Cormorant,
                            fontWeight = FontWeight.Medium, fontSize = 13.sp, letterSpacing = 5.sp)
                    }
                    Box(
                        Modifier.border(1.dp, GoldLight.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text("PLATINUM", color = GoldLight, fontFamily = Manrope,
                            fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom) {
                    Column {
                        Text("АЛЕКСАНДР ВОРОНОВ", color = Text, fontFamily = Cormorant,
                            fontWeight = FontWeight.Medium, fontSize = 19.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("ЧЛЕН КЛУБА С 2021", color = Dim45, fontFamily = Manrope,
                            fontWeight = FontWeight.Medium, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Box(Modifier.size(42.dp, 30.dp).clip(RoundedCornerShape(6.dp)).background(GoldSwatchBrush))
                }
            }
        }

        Spacer(Modifier.height(26.dp))

        // ── Stats ──
        Row(
            Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(18.dp))
                .background(Card).border(1.dp, GoldB16, RoundedCornerShape(18.dp)),
        ) {
            Stat("48 600", "баллов", Modifier.weight(1f))
            Divider()
            Stat("12", "привилегий", Modifier.weight(1f))
            Divider()
            Stat("87", "визитов", Modifier.weight(1f))
        }

        Spacer(Modifier.height(26.dp))

        // ── Menu ──
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card)
                .border(1.dp, GoldB14, RoundedCornerShape(18.dp)),
        ) {
            Data.profileMenu.forEachIndexed { i, row ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(row, color = Text, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    SvgIcon(forwardChevron(Gold.copy(alpha = 0.5f)), 8f, 14f, 7.dp, 13.dp)
                }
                if (i < Data.profileMenu.lastIndex) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(GoldB09))
                }
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(modifier.padding(vertical = 18.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = GoldLight, fontFamily = Cormorant, fontSize = 24.sp)
        Spacer(Modifier.height(7.dp))
        Text(label.uppercase(), color = Dim40, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
            fontSize = 8.5.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
private fun Divider() {
    Box(Modifier.width(1.dp).fillMaxHeight().background(GoldB14))
}
