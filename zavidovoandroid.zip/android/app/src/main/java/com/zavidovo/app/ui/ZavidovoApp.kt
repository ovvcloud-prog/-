package com.zavidovo.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Screen
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.screens.*
import com.zavidovo.app.ui.theme.*

@Composable
fun ZavidovoApp() {
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var serviceId by rememberSaveable { mutableStateOf("spa-ritual") }

    val onNav: (Screen) -> Unit = { screen = it }
    val onOpen: (String) -> Unit = { serviceId = it; screen = Screen.Booking }

    Column(
        // Content scrolls edge-to-edge under the status bar (each screen
        // reserves 60.dp at the top); only the nav bar needs insetting.
        Modifier.fillMaxSize().background(Bg)
            .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
        // Scrollable content area — Concierge manages its own height/scroll.
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                Screen.Concierge -> ConciergeScreen()
                else -> {
                    val scroll = rememberScrollState()
                    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
                        when (screen) {
                            Screen.Home -> HomeScreen(onNav, onOpen)
                            Screen.Services -> ServicesScreen(onOpen)
                            Screen.Booking -> BookingScreen(serviceId, onBack = { screen = Screen.Services })
                            Screen.Events -> EventsScreen(onBack = { screen = Screen.Home })
                            Screen.Map -> MapScreen()
                            Screen.Profile -> ProfileScreen()
                            else -> {}
                        }
                    }
                }
            }
        }
        BottomBar(screen, onNav)
    }
}

@Composable
private fun BottomBar(screen: Screen, onNav: (Screen) -> Unit) {
    val homeActive = screen == Screen.Home || screen == Screen.Events
    val svcActive = screen == Screen.Services || screen == Screen.Booking

    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xDB0A0A0B), Bg)))
            .padding(start = 12.dp, end = 12.dp, top = 11.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.Top,
    ) {
        Tab("Главная", homeActive, { homeTabPaths(it) }) { onNav(Screen.Home) }
        Tab("Услуги", svcActive, { servicesTabPaths(it) }) { onNav(Screen.Services) }
        Tab("Карта", screen == Screen.Map, { mapTabPaths(it) }) { onNav(Screen.Map) }
        Tab("Консьерж", screen == Screen.Concierge, { conciergeTabPaths(it) }) { onNav(Screen.Concierge) }
        Tab("Профиль", screen == Screen.Profile, { profileTabPaths(it) }) { onNav(Screen.Profile) }
    }
}

@Composable
private fun Tab(
    label: String,
    active: Boolean,
    paths: (Color) -> List<IconPath>,
    onClick: () -> Unit,
) {
    val color = if (active) Gold else Dim40
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(60.dp).clickable(onClick = onClick),
    ) {
        SvgIcon(paths(color), 20f, 20f, 21.dp, 21.dp)
        Spacer(Modifier.height(6.dp))
        Text(label.uppercase(), color = color, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
            fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}
