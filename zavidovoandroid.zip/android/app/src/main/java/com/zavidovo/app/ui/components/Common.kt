package com.zavidovo.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Service
import com.zavidovo.app.ui.theme.*

/** The recurring gold uppercase section header. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = Gold,
        fontFamily = Manrope,
        fontWeight = FontWeight.SemiBold,
        fontSize = 10.sp,
        letterSpacing = 2.5.sp,
    )
}

/** Catalog / recommendation row. */
@Composable
fun ServiceCard(service: Service, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Card)
            .border(1.dp, GoldB14, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(HeroBrush),
        ) {
            Text(
                service.hero,
                color = Gold.copy(alpha = 0.5f),
                fontFamily = Cormorant,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                letterSpacing = 3.sp,
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(service.label.uppercase(), color = Gold, fontFamily = Manrope,
                fontWeight = FontWeight.SemiBold, fontSize = 8.5.sp, letterSpacing = 2.sp)
            Spacer(Modifier.size(6.dp))
            Text(service.name, color = Text, fontFamily = Cormorant,
                fontWeight = FontWeight.Medium, fontSize = 16.sp)
            Spacer(Modifier.size(5.dp))
            Text(service.desc, color = Dim45, fontFamily = Manrope, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text("ОТ", color = Dim34, fontFamily = Manrope, fontWeight = FontWeight.Medium,
                fontSize = 9.sp, letterSpacing = 1.sp)
            Spacer(Modifier.size(6.dp))
            Text("${service.price} ₽", color = GoldLight, fontFamily = Manrope,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}
