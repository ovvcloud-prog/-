package com.zavidovo.app.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.zavidovo.app.R

// Cormorant Garamond — display / serif role
val Cormorant = FontFamily(
    Font(R.font.cormorant_300, FontWeight.Light),
    Font(R.font.cormorant_400, FontWeight.Normal),
    Font(R.font.cormorant_500, FontWeight.Medium),
    Font(R.font.cormorant_600, FontWeight.SemiBold),
)

// Manrope — interface / sans role
val Manrope = FontFamily(
    Font(R.font.manrope_300, FontWeight.Light),
    Font(R.font.manrope_400, FontWeight.Normal),
    Font(R.font.manrope_500, FontWeight.Medium),
    Font(R.font.manrope_600, FontWeight.SemiBold),
    Font(R.font.manrope_700, FontWeight.Bold),
)
