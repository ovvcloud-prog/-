package com.zavidovo.app.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.zavidovo.app.ui.theme.Cormorant
import com.zavidovo.app.ui.theme.Gold

// ─── The «З» (Земля) shield logo from the brand book ───────────
@Composable
fun ZLogo(size: Dp, color: Color = Gold, modifier: Modifier = Modifier) {
    Box(contentAlignment = Alignment.Center, modifier = modifier.size(size)) {
        SvgIcon(
            paths = listOf(
                IconPath(
                    "M22 3 L39 11.5 V29 C39 40 30.5 47 22 49 C13.5 47 5 40 5 29 V11.5 Z",
                    stroke = color, strokeWidth = 2f,
                )
            ),
            viewportWidth = 44f, viewportHeight = 52f,
            width = size, height = size,
        )
        Text(
            "З",
            color = color,
            fontFamily = Cormorant,
            fontWeight = FontWeight.SemiBold,
            fontSize = (size.value * 0.5f).sp,
            textAlign = TextAlign.Center,
        )
    }
}

// ─── Quick-action icons (viewBox 0 0 20 20) ────────────────────
fun spaPaths(c: Color) = listOf(
    IconPath("M10 3 C13 8 14.5 10.5 14.5 12.5 A4.5 4.5 0 0 1 5.5 12.5 C5.5 10.5 7 8 10 3Z", stroke = c, strokeWidth = 1.3f)
)
fun golfPaths(c: Color) = listOf(
    IconPath("M6.5 3V17.5", stroke = c, strokeWidth = 1.3f),
    IconPath("M6.5 3.6 H14 L11.6 6.6 L14 9.6 H6.5", stroke = c, strokeWidth = 1.3f),
)
fun diningPaths(c: Color) = listOf(
    IconPath("M6.5 3.5h7l-.7 4.2a2.9 2.9 0 0 1-5.6 0Z", stroke = c, strokeWidth = 1.3f),
    IconPath("M10 10.7V16.5", stroke = c, strokeWidth = 1.3f),
    IconPath("M7 16.5h6", stroke = c, strokeWidth = 1.3f),
)
fun conciergePaths(c: Color) = listOf(
    IconPath("M5 14h10l-1.2-1.6V9a3.8 3.8 0 0 0-7.6 0v3.4Z", stroke = c, strokeWidth = 1.3f),
    IconPath("M8.4 16.4a1.8 1.8 0 0 0 3.2 0", stroke = c, strokeWidth = 1.3f),
)

// ─── Tab-bar icons (viewBox 0 0 20 20) ─────────────────────────
fun homeTabPaths(c: Color) = listOf(
    IconPath("M3 9.2 10 3.5 17 9.2V16a1 1 0 0 1-1 1h-3.2v-4.6H7.2V17H4a1 1 0 0 1-1-1Z", stroke = c, strokeWidth = 1.4f)
)
fun servicesTabPaths(c: Color) = listOf(
    IconPath("M3.2 3.2 h5.6 v5.6 h-5.6 Z", stroke = c, strokeWidth = 1.4f),
    IconPath("M11.2 3.2 h5.6 v5.6 h-5.6 Z", stroke = c, strokeWidth = 1.4f),
    IconPath("M3.2 11.2 h5.6 v5.6 h-5.6 Z", stroke = c, strokeWidth = 1.4f),
    IconPath("M11.2 11.2 h5.6 v5.6 h-5.6 Z", stroke = c, strokeWidth = 1.4f),
)
fun mapTabPaths(c: Color) = listOf(
    IconPath("M10 17.5s5.5-4.8 5.5-9.2A5.5 5.5 0 0 0 4.5 8.3c0 4.4 5.5 9.2 5.5 9.2Z", stroke = c, strokeWidth = 1.4f),
    IconPath("M10 6 a2 2 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.4f),
)
fun conciergeTabPaths(c: Color) = listOf(
    IconPath("M3.5 6A2.5 2.5 0 0 1 6 3.5h8A2.5 2.5 0 0 1 16.5 6v5A2.5 2.5 0 0 1 14 13.5H8.5L5 16.5V13.5A2.5 2.5 0 0 1 3.5 11Z", stroke = c, strokeWidth = 1.4f)
)
fun profileTabPaths(c: Color) = listOf(
    IconPath("M10 4 a3 3 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.4f),
    IconPath("M4.5 16.5c0-3 2.5-4.7 5.5-4.7s5.5 1.7 5.5 4.7", stroke = c, strokeWidth = 1.4f),
)

// ─── Misc icons ────────────────────────────────────────────────
fun carPaths(c: Color) = listOf(
    IconPath("M4 11l1.6-3.8A2 2 0 0 1 7.45 6h9.1a2 2 0 0 1 1.85 1.2L20 11", stroke = c, strokeWidth = 1.3f),
    IconPath("M3 11h18v4.5a1 1 0 0 1-1 1h-1.2", stroke = c, strokeWidth = 1.3f),
    IconPath("M5.2 16.5H4a1 1 0 0 1-1-1V11", stroke = c, strokeWidth = 1.3f),
    IconPath("M7.4 14.9 a1.7 1.7 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.3f),
    IconPath("M16.6 14.9 a1.7 1.7 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.3f),
)
fun searchPaths(c: Color) = listOf(
    IconPath("M9 3 a6 6 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.5f),
    IconPath("M13.5 13.5 L17 17", stroke = c, strokeWidth = 1.5f),
)
fun locationPinPaths(c: Color) = listOf(
    IconPath("M10 17.5s5.5-4.8 5.5-9.2A5.5 5.5 0 0 0 4.5 8.3c0 4.4 5.5 9.2 5.5 9.2Z", stroke = c, strokeWidth = 1.5f),
    IconPath("M10 6 a2 2 0 1 0 0.001 0 Z", stroke = c, strokeWidth = 1.5f),
)
fun sendPaths(c: Color) = listOf(
    IconPath("M17 3 L9 11", stroke = c, strokeWidth = 1.8f),
    IconPath("M17 3 L12 17 L9 11 L3 8 Z", stroke = c, strokeWidth = 1.8f),
)
// back chevron (viewBox 0 0 12 20)
fun backChevron(c: Color) = listOf(
    IconPath("M10 2 L2 10 l8 8", stroke = c, strokeWidth = 2f)
)
// forward chevron (viewBox 0 0 8 14)
fun forwardChevron(c: Color) = listOf(
    IconPath("M1 1l6 6-6 6", stroke = c, strokeWidth = 1.8f)
)
