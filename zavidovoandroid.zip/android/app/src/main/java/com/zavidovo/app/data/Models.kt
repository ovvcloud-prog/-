package com.zavidovo.app.data

// ─── Domain models ─────────────────────────────────────────────
data class Service(
    val id: String,
    val label: String,
    val cat: String,
    val hero: String,
    val name: String,
    val desc: String,
    val price: String,
    val long: String,
)

data class EventItem(
    val day: String,
    val month: String,
    val date: String,
    val tag: String,
    val title: String,
    val place: String,
)

data class QuickReply(val text: String, val reply: String)

data class ChatMessage(val me: Boolean, val text: String)

data class MapPin(val name: String, val x: Float, val y: Float)

data class Category(val key: String, val label: String)

// ─── Static catalog (mirrors the prototype's renderVals) ───────
object Data {
    val services = listOf(
        Service("spa-ritual", "Спа", "spa", "SPA", "Спа-ритуал «Кедровый»",
            "Глубокое расслабление в кедровой парной", "12 000",
            "Авторская программа в кедровой парной с травяными настоями, пилингом и завершающим массажем. Полтора часа уединения и тишины на берегу."),
        Service("dining-prichal", "Рестораны", "dining", "DINING", "Ужин в «Причале»",
            "Авторская кухня на берегу водохранилища", "6 500",
            "Сезонное меню от шеф-повара с акцентом на локальные продукты и рыбу. Панорамная терраса с видом на воду и закат."),
        Service("golf-18", "Гольф", "golf", "GOLF", "Гольф · 18 лунок",
            "Чемпионское поле par-72", "9 000",
            "Раунд на чемпионском поле par-72, спроектированном по международным стандартам. Включает аренду кара и сопровождение маршала."),
        Service("yacht-sunset", "Яхт-клуб", "yacht", "YACHT", "Закатный круиз",
            "Прогулка на яхте по водохранилищу", "18 000",
            "Двухчасовой круиз на моторной яхте вдоль живописных берегов Иваньковского водохранилища с шампанским и канапе на борту."),
        Service("riding", "Спорт", "sport", "RIDING", "Конная прогулка",
            "По заповедным лесным тропам", "4 500",
            "Прогулка верхом по заповедным тропам в сопровождении инструктора. Подходит для всех уровней подготовки."),
        Service("hammam", "Спа", "spa", "HAMMAM", "Хаммам & массаж",
            "Ритуал на двоих", "16 000",
            "Турецкий хаммам с пенным массажем и расслабляющей программой на двоих. Приватная зона и чайная церемония после ритуала."),
        Service("wine-dinner", "Рестораны", "dining", "WINE", "Винный ужин",
            "Сет-меню с сомелье", "11 000",
            "Гастрономический сет из пяти подач в сопровождении сомелье и подобранных вин из коллекции винного погреба курорта."),
    )

    fun service(id: String): Service = services.firstOrNull { it.id == id } ?: services.first()

    val recommended = listOf(services[0], services[3], services[1])

    val categories = listOf(
        Category("all", "Все"),
        Category("spa", "Спа"),
        Category("dining", "Рестораны"),
        Category("golf", "Гольф"),
        Category("yacht", "Яхт-клуб"),
        Category("sport", "Спорт"),
    )

    val events = listOf(
        EventItem("28", "июн", "28 ИЮНЯ · СБ", "Музыка", "Закрытый концерт у воды", "Амфитеатр"),
        EventItem("02", "июл", "2 ИЮЛЯ · СР", "Гастро", "Дегустация бургундских вин", "Винный погреб"),
        EventItem("05", "июл", "5 ИЮЛЯ · СБ", "Спорт", "Турнир Zavidovo Open", "Гольф-клуб"),
        EventItem("12", "июл", "12 ИЮЛЯ · СБ", "Велнес", "Йога на рассвете", "Терраса Spa Palace"),
    )

    val quickReplies = listOf(
        QuickReply("Забронировать столик", "С удовольствием. На какое время накрыть стол в «Причале»?"),
        QuickReply("Заказать трансфер", "Подача авто к Гранд-отелю через 15 минут. Подтвердить?"),
        QuickReply("Спа на двоих", "Свободно сегодня в 18:00 и 20:00. Какое время предпочитаете?"),
    )

    val bookingDates = listOf(
        "СБ" to "28", "ВС" to "29", "ПН" to "30", "ВТ" to "01", "СР" to "02",
    )
    val bookingTimes = listOf("12:00", "15:30", "18:00", "20:00")

    val mapPins = listOf(
        MapPin("Гранд-отель", 0.46f, 0.40f),
        MapPin("Гольф-клуб", 0.74f, 0.26f),
        MapPin("Spa Palace", 0.24f, 0.34f),
        MapPin("Яхт-клуб", 0.60f, 0.68f),
        MapPin("«Причал»", 0.34f, 0.60f),
    )
    val mapLegend = listOf("Отель", "Гольф", "Спа", "Яхт-клуб", "Рестораны", "Резиденции")

    val profileMenu = listOf(
        "История посещений", "Мои привилегии", "Гости и доступ", "Способы оплаты", "Настройки",
    )
}

// ─── Navigation ────────────────────────────────────────────────
enum class Screen { Home, Services, Booking, Events, Concierge, Map, Profile }
