package com.zavidovo.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.theme.*

@Composable
fun MapScreen() {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 28.dp)) {
        Text("НАВИГАЦИЯ", color = Gold, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(11.dp))
        Text("Карта курорта", color = Text, fontFamily = Cormorant, fontWeight = FontWeight.Light, fontSize = 34.sp)
        Spacer(Modifier.height(22.dp))

        var boxSize by remember { mutableStateOf(IntSize.Zero) }
        val density = LocalDensity.current

        Box(
            Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0E0D10)).border(1.dp, GoldB20, RoundedCornerShape(22.dp))
                .onSizeChanged { boxSize = it },
        ) {
            // Stylised terrain (viewBox 360 x 380)
            Canvas(Modifier.fillMaxSize()) {
                val sx = size.width / 360f
                val sy = size.height / 380f
                // Terrain base fill — full canvas, outside the viewBox transform.
                drawRect(Brush.radialGradient(
                    colors = listOf(Color(0xFF16181A), Color(0xFF0B0C0D)),
                    center = Offset(size.width * 0.4f, size.height * 0.35f),
                    radius = size.maxDimension * 0.8f,
                ))
                withTransform({ scale(sx, sy, pivot = Offset.Zero) }) {
                    drawPath(
                        PathParser().parsePathString(
                            "M-20 250 C 80 220 130 280 220 260 C 300 244 340 280 380 268 L380 400 L-20 400 Z").toPath(),
                        color = Color(0xFF0C1418))
                    drawPath(
                        PathParser().parsePathString(
                            "M-20 250 C 80 220 130 280 220 260 C 300 244 340 280 380 268").toPath(),
                        color = Gold.copy(alpha = 0.25f), style = Stroke(width = 1f))
                    drawPath(
                        PathParser().parsePathString(
                            "M40 70 C 120 110 110 180 200 200 C 280 218 250 150 330 140").toPath(),
                        color = Gold.copy(alpha = 0.22f),
                        style = Stroke(width = 1.4f, cap = StrokeCap.Round,
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(2f, 6f))))
                    drawPath(
                        PathParser().parsePathString(
                            "M70 330 C 130 300 150 250 230 250").toPath(),
                        color = Gold.copy(alpha = 0.18f),
                        style = Stroke(width = 1.4f, cap = StrokeCap.Round,
                            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(2f, 6f))))
                    val dots = listOf(60f to 120f, 95f to 95f, 130f to 140f, 300f to 90f,
                        270f to 60f, 320f to 200f, 40f to 200f)
                    dots.forEach { (x, y) ->
                        drawCircle(Gold.copy(alpha = 0.06f), radius = 2f, center = Offset(x, y))
                    }
                }
            }

            // Pins
            Data.mapPins.forEach { p ->
                val wDp = with(density) { boxSize.width.toDp() }
                val hDp = with(density) { boxSize.height.toDp() }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.offset(x = wDp * p.x - 50.dp, y = hDp * p.y - 28.dp),
                ) {
                    Box(
                        Modifier.clip(RoundedCornerShape(20.dp)).background(GoldChipBrush)
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                    ) {
                        Text(p.name, color = Bg, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp, letterSpacing = 0.5.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(Modifier.size(11.dp).clip(CircleShape).background(Gold)
                        .border(2.dp, Bg, CircleShape))
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        FlowRow(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Data.mapLegend.forEach { l ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Card)
                        .border(1.dp, GoldB14, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Gold))
                    Spacer(Modifier.width(8.dp))
                    Text(l, color = Dim60, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 12.sp)
                }
            }
        }
    }
}
