package com.zavidovo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Data
import com.zavidovo.app.data.Screen
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*

@Composable
fun HomeScreen(onNav: (Screen) -> Unit, onOpen: (String) -> Unit) {
    var valetRequested by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 28.dp)) {

        // ── Header ──
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
        ) {
            Column {
                Text("ДОБРЫЙ ВЕЧЕР", color = Gold, fontFamily = Manrope,
                    fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(11.dp))
                Text("Александр", color = Text, fontFamily = Cormorant,
                    fontWeight = FontWeight.Light, fontSize = 32.sp)
                Spacer(Modifier.height(9.dp))
                Text("Завидово · +14° · ясно", color = Dim40, fontFamily = Manrope,
                    fontWeight = FontWeight.Medium, fontSize = 11.sp)
            }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF23201D), Color(0xFF0C0B0D))))
                    .border(1.dp, GoldB45, CircleShape)
                    .clickable { onNav(Screen.Profile) },
            ) { ZLogo(size = 23.dp) }
        }

        Spacer(Modifier.height(24.dp))

        // ── Membership strip ──
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1A1714), Color(0xFF0E0D0E))))
                .border(1.dp, GoldB30, RoundedCornerShape(16.dp))
                .clickable { onNav(Screen.Profile) }
                .padding(horizontal = 18.dp, vertical = 15.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp, 24.dp).clip(RoundedCornerShape(5.dp)).background(GoldSwatchBrush))
                Spacer(Modifier.width(13.dp))
                Column {
                    Text("КЛУБНАЯ КАРТА", color = Dim40, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 2.5.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("PLATINUM", color = GoldLight, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 1.5.sp)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("48 600", color = Text, fontFamily = Cormorant,
                    fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text("БАЛЛОВ", color = Dim40, fontFamily = Manrope,
                    fontWeight = FontWeight.Medium, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }

        Spacer(Modifier.height(26.dp))

        // ── Quick actions ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            QuickAction("Спа", { spaPaths(Gold) }) { onOpen("spa-ritual") }
            QuickAction("Гольф", { golfPaths(Gold) }) { onOpen("golf-18") }
            QuickAction("Ресторан", { diningPaths(Gold) }) { onOpen("dining-prichal") }
            QuickAction("Консьерж", { conciergePaths(Gold) }) { onNav(Screen.Concierge) }
        }

        Spacer(Modifier.height(30.dp))

        // ── Parking & valet ──
        SectionLabel("Парковка & валет")
        Spacer(Modifier.height(14.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF17161A), Color(0xFF0E0D0F))))
                .border(1.dp, GoldB20, RoundedCornerShape(22.dp))
                .padding(18.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(46.dp).clip(RoundedCornerShape(13.dp))
                            .background(Color(0xFF0C0B0D)).border(1.dp, GoldB28, RoundedCornerShape(13.dp)),
                    ) { SvgIcon(carPaths(Gold), 24f, 24f, 23.dp, 23.dp) }
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text("Maybach S 580", color = Text, fontFamily = Cormorant,
                            fontWeight = FontWeight.Medium, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("О 777 ОО · 177", color = Gold.copy(alpha = 0.75f), fontFamily = Manrope,
                            fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Green))
                        Spacer(Modifier.width(6.dp))
                        Text(if (valetRequested) "Подаётся" else "На парковке",
                            color = Dim60, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    Text("Паркинг A · место 12", color = Dim40, fontFamily = Manrope,
                        fontWeight = FontWeight.Medium, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (!valetRequested) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                        .border(1.dp, GoldB50, RoundedCornerShape(13.dp))
                        .clickable { valetRequested = true }.padding(14.dp),
                ) {
                    Text("ПОДАТЬ АВТО", color = GoldLight, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                }
            } else {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                        .background(Gold.copy(alpha = 0.07f))
                        .border(1.dp, GoldB30, RoundedCornerShape(13.dp))
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("АВТО ПОДАЁТСЯ", color = GoldLight, fontFamily = Manrope,
                            fontWeight = FontWeight.SemiBold, fontSize = 11.sp, letterSpacing = 1.sp)
                        Text("~ 7 мин", color = Dim60, fontFamily = Manrope,
                            fontWeight = FontWeight.Medium, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp))
                        .background(Gold.copy(alpha = 0.15f))) {
                        Box(Modifier.fillMaxWidth(0.38f).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                            .background(Brush.horizontalGradient(listOf(GoldLighter, Gold))))
                    }
                    Spacer(Modifier.height(9.dp))
                    Text("Подача к подъезду Гранд-отеля", color = Dim40, fontFamily = Manrope, fontSize = 11.sp)
                }
            }
        }

        Spacer(Modifier.height(30.dp))

        // ── Upcoming ──
        SectionLabel("Ближайшее")
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier.fillMaxWidth().height(172.dp).clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1F1D22), Color(0xFF0C0B0D))))
                .border(1.dp, GoldB20, RoundedCornerShape(22.dp))
                .clickable { onOpen("spa-ritual") },
        ) {
            Text("SPA RITUAL", color = Gold.copy(alpha = 0.14f), fontFamily = Cormorant,
                fontWeight = FontWeight.SemiBold, fontSize = 30.sp, letterSpacing = 9.sp,
                modifier = Modifier.align(Alignment.Center))
            Column(
                Modifier.align(Alignment.BottomStart)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEB080809))))
                    .fillMaxWidth().padding(18.dp),
            ) {
                Text("СЕГОДНЯ · 18:00 · SPA PALACE", color = Gold, fontFamily = Manrope,
                    fontWeight = FontWeight.Medium, fontSize = 9.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("Спа-ритуал «Кедровый»", color = Text, fontFamily = Cormorant, fontSize = 20.sp)
            }
        }

        Spacer(Modifier.height(30.dp))

        // ── Events strip ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom) {
            SectionLabel("Афиша")
            Text("Все ›", color = Dim50, fontFamily = Manrope, fontWeight = FontWeight.Medium,
                fontSize = 11.sp, modifier = Modifier.clickable { onNav(Screen.Events) })
        }
        Spacer(Modifier.height(14.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            items(Data.events.size) { i ->
                val e = Data.events[i]
                Column(
                    Modifier.width(150.dp).clip(RoundedCornerShape(16.dp)).background(Card)
                        .border(1.dp, GoldB16, RoundedCornerShape(16.dp))
                        .clickable { onNav(Screen.Events) },
                ) {
                    Box(
                        Modifier.fillMaxWidth().height(96.dp)
                            .background(Brush.linearGradient(listOf(Color(0xFF211F24), Color(0xFF0C0B0D))))
                            .padding(12.dp),
                    ) {
                        Box(
                            Modifier.border(1.dp, GoldB40, RoundedCornerShape(20.dp))
                                .padding(horizontal = 7.dp, vertical = 4.dp),
                        ) {
                            Text(e.tag.uppercase(), color = Gold, fontFamily = Manrope,
                                fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        }
                    }
                    Column(Modifier.padding(12.dp)) {
                        Text(e.date, color = Dim40, fontFamily = Manrope,
                            fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(7.dp))
                        Text(e.title, color = Text, fontFamily = Cormorant, fontSize = 15.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(30.dp))

        // ── Recommendations ──
        SectionLabel("Рекомендуем")
        Spacer(Modifier.height(14.dp))
        Data.recommended.forEach { s ->
            ServiceCard(s, onClick = { onOpen(s.id) })
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun QuickAction(label: String, paths: () -> List<IconPath>, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(68.dp).clickable(onClick = onClick),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp))
                .background(Card).border(1.dp, GoldB28, RoundedCornerShape(18.dp)),
        ) { SvgIcon(paths(), 20f, 20f, 22.dp, 22.dp) }
        Spacer(Modifier.height(9.dp))
        Text(label, color = Dim60, fontFamily = Manrope, fontWeight = FontWeight.Medium, fontSize = 10.sp)
    }
}
