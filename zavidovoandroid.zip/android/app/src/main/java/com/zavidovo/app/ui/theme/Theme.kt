package com.zavidovo.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ZavidovoColors = darkColorScheme(
    primary = Gold,
    onPrimary = Bg,
    background = Bg,
    onBackground = Text,
    surface = Card,
    onSurface = Text,
)

@Composable
fun ZavidovoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZavidovoColors,
        content = content,
    )
}
