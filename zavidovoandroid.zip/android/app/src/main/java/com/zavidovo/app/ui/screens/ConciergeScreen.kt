package com.zavidovo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.ChatMessage
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ConciergeScreen() {
    val chat = remember {
        mutableStateListOf(ChatMessage(false, "Добрый вечер, Александр. Чем можем быть полезны сегодня?"))
    }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        // Header
        Column(Modifier.fillMaxWidth()) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 18.dp),
          ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(46.dp).clip(CircleShape)
                        .background(androidx.compose.ui.graphics.Brush.radialGradient(
                            listOf(Color(0xFF23201D), Color(0xFF0C0B0D))))
                        .border(1.dp, GoldB45, CircleShape),
                ) { ZLogo(size = 20.dp) }
                Spacer(Modifier.width(13.dp))
                Column {
                    Text("Консьерж Завидово", color = Text, fontFamily = Cormorant,
                        fontWeight = FontWeight.Medium, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Green))
                        Spacer(Modifier.width(6.dp))
                        Text("на связи · 24/7", color = Dim45, fontFamily = Manrope,
                            fontWeight = FontWeight.Medium, fontSize = 10.sp)
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(GoldB14))
        }

        // Messages
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp),
            contentPadding = PaddingValues(vertical = 22.dp),
        ) {
            item {
                Text("СЕГОДНЯ", color = Dim30, fontFamily = Manrope, fontWeight = FontWeight.Medium,
                    fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
            items(chat.size) { i ->
                val m = chat[i]
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.me) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.fillMaxWidth(0.78f).wrapContentWidth(if (m.me) Alignment.End else Alignment.Start)
                    ) {
                        Box(
                            Modifier.clip(RoundedCornerShape(
                                topStart = 18.dp, topEnd = 18.dp,
                                bottomEnd = if (m.me) 6.dp else 18.dp,
                                bottomStart = if (m.me) 18.dp else 6.dp))
                                .then(if (m.me) Modifier.background(GoldChipBrush)
                                      else Modifier.background(Color(0xFF17161A)).border(1.dp, GoldB16,
                                          RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 6.dp)))
                                .padding(horizontal = 16.dp, vertical = 13.dp),
                        ) {
                            Text(m.text, color = if (m.me) Bg else Text, fontFamily = Manrope,
                                fontSize = 13.5.sp, lineHeight = 19.sp)
                        }
                    }
                }
            }
        }

        // Quick replies + input
        Box(Modifier.fillMaxWidth().height(1.dp).background(GoldB14))
        Column(
            Modifier.fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 16.dp),
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(Data.quickReplies.size) { i ->
                    val q = Data.quickReplies[i]
                    Box(
                        Modifier.clip(RoundedCornerShape(30.dp)).border(1.dp, GoldB35, RoundedCornerShape(30.dp))
                            .clickable {
                                chat.add(ChatMessage(true, q.text))
                                scope.launch {
                                    delay(750)
                                    chat.add(ChatMessage(false, q.reply))
                                }
                            }
                            .padding(horizontal = 15.dp, vertical = 9.dp),
                    ) {
                        Text(q.text, color = GoldLight, fontFamily = Manrope,
                            fontWeight = FontWeight.Medium, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(13.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Card)
                    .border(1.dp, GoldB20, RoundedCornerShape(30.dp))
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Сообщение консьержу…", color = Dim40, fontFamily = Manrope, fontSize = 14.sp,
                    modifier = Modifier.weight(1f))
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(GoldChipBrush),
                ) { SvgIcon(sendPaths(Bg), 20f, 20f, 16.dp, 16.dp) }
            }
        }
    }
}
