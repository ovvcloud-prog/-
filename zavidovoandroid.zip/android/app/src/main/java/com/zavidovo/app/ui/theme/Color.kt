package com.zavidovo.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ─── Palette — premium black & gold ───────────────────────────
val Bg = Color(0xFF0A0A0B)
val Card = Color(0xFF141315)
val Text = Color(0xFFF4F1EA)

val Gold = Color(0xFFC9A86A)
val GoldLight = Color(0xFFE7D4A0)
val GoldLighter = Color(0xFFEBD9A8)
val GoldDeep = Color(0xFFB89455)
val GoldDeepest = Color(0xFF9E7C40)

val Green = Color(0xFF7BC49A)

// Text opacities over the cream Text color
val Dim30 = Color(0x4DF4F1EA)
val Dim34 = Color(0x57F4F1EA)
val Dim40 = Color(0x66F4F1EA)
val Dim45 = Color(0x73F4F1EA)
val Dim50 = Color(0x80F4F1EA)
val Dim60 = Color(0x99F4F1EA)

// Gold borders at various opacities
val GoldB09 = Color(0x17C9A86A)
val GoldB14 = Color(0x24C9A86A)
val GoldB16 = Color(0x29C9A86A)
val GoldB18 = Color(0x2EC9A86A)
val GoldB20 = Color(0x33C9A86A)
val GoldB28 = Color(0x47C9A86A)
val GoldB30 = Color(0x4DC9A86A)
val GoldB35 = Color(0x59C9A86A)
val GoldB40 = Color(0x66C9A86A)
val GoldB45 = Color(0x73C9A86A)
val GoldB50 = Color(0x80C9A86A)

// Hero placeholder tiles
val Hero1 = Color(0xFF1F1D22)
val Hero2 = Color(0xFF0C0B0D)
val HeroBrush = Brush.linearGradient(listOf(Hero1, Hero2))

// ─── Gradients ────────────────────────────────────────────────
val GoldBrush = Brush.linearGradient(listOf(GoldLighter, Gold))
val GoldChipBrush = Brush.linearGradient(listOf(GoldLighter, Gold))
val GoldButtonBrush = Brush.linearGradient(listOf(GoldLighter, Gold, GoldDeep))
val GoldSwatchBrush = Brush.linearGradient(listOf(GoldLighter, Gold, GoldDeepest))
