package com.zavidovo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*

@Composable
fun ServicesScreen(onOpen: (String) -> Unit) {
    var cat by rememberSaveable { mutableStateOf("all") }
    val filtered = if (cat == "all") Data.services else Data.services.filter { it.cat == cat }

    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 28.dp)) {
        SectionLabel("Каталог", Modifier.padding(bottom = 11.dp))
        Text("Услуги курорта", color = Text, fontFamily = Cormorant,
            fontWeight = FontWeight.Light, fontSize = 34.sp)
        Spacer(Modifier.height(22.dp))

        // Search (visual)
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card)
                .border(1.dp, GoldB18, RoundedCornerShape(14.dp))
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SvgIcon(searchPaths(Dim45), 20f, 20f, 17.dp, 17.dp)
            Spacer(Modifier.width(11.dp))
            Text("Поиск по услугам", color = Dim40, fontFamily = Manrope, fontSize = 14.sp)
        }
        Spacer(Modifier.height(18.dp))

        // Categories
        LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            items(Data.categories.size) { i ->
                val c = Data.categories[i]
                val active = cat == c.key
                Box(
                    Modifier.clip(RoundedCornerShape(30.dp))
                        .then(if (active) Modifier.background(GoldChipBrush) else Modifier.background(Card))
                        .then(if (active) Modifier else Modifier.border(1.dp, GoldB20, RoundedCornerShape(30.dp)))
                        .clickable { cat = c.key }
                        .padding(horizontal = 16.dp, vertical = 9.dp),
                ) {
                    Text(c.label, color = if (active) Bg else Dim60, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 11.sp, letterSpacing = 0.5.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))

        filtered.forEach { s ->
            ServiceCard(s, onClick = { onOpen(s.id) })
            Spacer(Modifier.height(12.dp))
        }
    }
}
