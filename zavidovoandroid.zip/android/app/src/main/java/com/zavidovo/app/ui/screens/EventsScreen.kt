package com.zavidovo.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zavidovo.app.data.Data
import com.zavidovo.app.ui.components.*
import com.zavidovo.app.ui.theme.*

@Composable
fun EventsScreen(onBack: () -> Unit) {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 60.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(38.dp).clip(CircleShape)
                    .border(1.dp, GoldB35, CircleShape).clickable(onClick = onBack),
            ) { SvgIcon(backChevron(Gold), 12f, 20f, 10.dp, 16.dp) }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("АФИША", color = Gold, fontFamily = Manrope, fontWeight = FontWeight.SemiBold,
                    fontSize = 9.sp, letterSpacing = 3.sp)
                Spacer(Modifier.height(7.dp))
                Text("События курорта", color = Text, fontFamily = Cormorant,
                    fontWeight = FontWeight.Light, fontSize = 27.sp)
            }
        }
        Spacer(Modifier.height(22.dp))

        Data.events.forEach { e ->
            Row(
                Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(18.dp)).background(Card)
                    .border(1.dp, GoldB16, RoundedCornerShape(18.dp)),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.width(84.dp).fillMaxHeight()
                        .background(Brush.linearGradient(listOf(Color(0xFF201E23), Color(0xFF0C0B0D))))
                        .padding(vertical = 22.dp),
                ) {
                    Text(e.day, color = GoldLight, fontFamily = Cormorant, fontWeight = FontWeight.Medium, fontSize = 28.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(e.month.uppercase(), color = Dim45, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Column(Modifier.weight(1f).padding(16.dp)) {
                    Text(e.tag.uppercase(), color = Gold, fontFamily = Manrope,
                        fontWeight = FontWeight.SemiBold, fontSize = 8.5.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(9.dp))
                    Text(e.title, color = Text, fontFamily = Cormorant, fontWeight = FontWeight.Medium, fontSize = 18.sp)
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SvgIcon(locationPinPaths(Dim40), 20f, 20f, 12.dp, 12.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(e.place, color = Dim50, fontFamily = Manrope, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}
